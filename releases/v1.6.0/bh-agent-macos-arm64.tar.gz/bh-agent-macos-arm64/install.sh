#!/usr/bin/env bash
set -euo pipefail

# macOS's stock sudoers does not set `secure_path`, so `env_reset` preserves the
# caller's PATH and root would resolve bare command names (curl, install,
# hostname) through directories the invoking user can write — Homebrew's
# /usr/local/bin on Intel Macs, or anything earlier on their PATH. Pin it.
PATH=/usr/bin:/bin:/usr/sbin:/sbin
export PATH

# Bracket ranges like [ -~] are matched in *collation* order, not ASCII order,
# and in a UTF-8 locale that order excludes ordinary alphanumerics — so the
# token validation below rejects every valid token unless the locale is pinned.
# `sudo` on macOS forwards the caller's LANG, so this cannot be left to chance.
LC_ALL=C
export LC_ALL

TOKEN=""
FORCE_CONFIG=""
TOKEN_FILE=""
NAME=""
API=""
INTERVAL=""
SCREENSHOTS=""
SCREENSHOT_INTERVAL=""

# Defaults for the two reporting subsystems, matching config.example.yaml and
# the Windows installer's dropdowns. Screen capture is off, and that is not a
# preference: ADR-008 requires a deliberate per-device decision, and forgetting
# to opt *out* cannot be undone once images have been uploaded.
DEFAULT_INTERVAL=5
DEFAULT_SCREENSHOT_INTERVAL=15

usage() {
  cat >&2 <<'USAGE'
usage: install.sh [--token-file PATH | --token VALUE] [--name NAME] [--api URL]
                  [--interval N] [--screenshots | --no-screenshots]
                  [--screenshot-interval N] [--force-config]

  --token-file  Read the device token from PATH (preferred: keeps the secret
                out of the process argument list, which is world-readable via
                /proc on Linux).
  --token       Device token as a literal argument. Discouraged; also readable
                from the environment variable BH_AGENT_SETUP_TOKEN instead.
  --name        Device name. Defaults to the hostname.
  --api         API base URL. Must be https:// (or http://localhost for dev).

  --interval    Minutes between device information and metrics uploads.
                1-1440, default 5.
  --screenshots Turn periodic screen capture ON for this device. Off unless
                this is passed. Recording the decision is all this does: each
                user must also run `bh-agent screenshots install` from their
                own session before anything is captured.
  --no-screenshots
                Explicitly off. Same as omitting --screenshots; useful to state
                the intent in a provisioning script.
  --screenshot-interval
                Minutes between captures. 1-1440, default 15. Written whether
                or not capture is on, so the value is already right if it is
                switched on later.

  --force-config
                Rewrite an existing config.yaml instead of preserving it. This
                is how a token is rotated or a device repointed.
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --token)      TOKEN="$2";      shift 2;;
    --force-config) FORCE_CONFIG=1;  shift 1;;
    --token-file) TOKEN_FILE="$2"; shift 2;;
    --name)       NAME="$2";       shift 2;;
    --api)        API="$2";        shift 2;;
    --interval)   INTERVAL="$2";   shift 2;;
    --screenshots)    SCREENSHOTS=1; shift 1;;
    --no-screenshots) SCREENSHOTS=0; shift 1;;
    --screenshot-interval) SCREENSHOT_INTERVAL="$2"; shift 2;;
    -h|--help)    usage; exit 0;;
    *) echo "unknown arg: $1" >&2; usage; exit 1;;
  esac
done

# Reject anything AgentConfig::validate would reject, here rather than after a
# cheerful "install complete" followed by a service that will not start.
# MAX_INTERVAL_MINUTES in src/config/mod.rs is one day.
validate_interval() {
  local flag="$1" value="$2"
  case "$value" in
    ''|*[!0-9]*)
      echo "$flag must be a whole number of minutes; got: $value" >&2; exit 1;;
  esac
  if (( value < 1 || value > 1440 )); then
    echo "$flag must be between 1 and 1440 minutes; got: $value" >&2; exit 1
  fi
}

# Interactive prompts must read from the terminal, not stdin: when this script
# runs via `curl | bash`, stdin is the exhausted script pipe and a plain `read`
# dies silently on EOF under `set -e`.
prompt() {
  local flags="$1" text="$2" __var="$3"
  if ! { : < /dev/tty; } 2>/dev/null; then
    echo "missing required argument (no terminal to prompt): $text" >&2
    echo "pass --token-file/--name/--api explicitly when running non-interactively" >&2
    exit 1
  fi
  local value
  read -r $flags -p "$text" value < /dev/tty
  [[ "$flags" == *s* ]] && echo
  printf -v "$__var" '%s' "$value"
}

# Ask, but never insist. Unlike the token and the API URL, every reporting
# option has a working default, so no terminal is not an error here — it just
# takes the default. That is what keeps `curl ... | bash` and RMM pushes working
# unchanged after these questions were added.
prompt_default() {
  local text="$1" __var="$2" default="$3" value=""
  if { : < /dev/tty; } 2>/dev/null; then
    read -r -p "$text [$default]: " value < /dev/tty || value=""
  fi
  [[ -n "$value" ]] || value="$default"
  printf -v "$__var" '%s' "$value"
}

# Token precedence: --token-file, then the environment, then --token, then a
# prompt. The first two keep the secret out of argv.
if [[ -n "$TOKEN_FILE" ]]; then
  [[ -r "$TOKEN_FILE" ]] || { echo "cannot read token file: $TOKEN_FILE" >&2; exit 1; }
  TOKEN="$(< "$TOKEN_FILE")"
  TOKEN="${TOKEN%%[$'\n\r']*}"
elif [[ -z "$TOKEN" && -n "${BH_AGENT_SETUP_TOKEN:-}" ]]; then
  TOKEN="$BH_AGENT_SETUP_TOKEN"
fi
# On an upgrade the token already lives in the preserved config, so do not force
# the operator to dig it out again just to replace the binary.
existing_config() {
  [[ -f /etc/bh-agent/config.yaml ]] || [[ -f "/Library/Application Support/bh-agent/config.yaml" ]]
}
# True when write_config will preserve what is already there, whatever else was
# passed. Computed once, because it decides whether asking anything makes sense:
# a question whose answer is then discarded is worse than no question.
UPGRADE_ONLY=0
if existing_config && [[ "$FORCE_CONFIG" != "1" ]]; then
  UPGRADE_ONLY=1
fi
if [[ -z "$TOKEN" ]] && existing_config && [[ "$FORCE_CONFIG" != "1" ]]; then
  echo "existing configuration found; upgrading binary and service only"
  # Placeholders only: write_config returns early when a config exists, so these
  # are never written anywhere. They exist so the validation below and the
  # interactive prompts do not block a non-interactive upgrade.
  TOKEN="upgrade-placeholder-unused"
  [[ -n "$API" ]] || API="https://placeholder.invalid/api/v1"
  [[ -n "$NAME" ]] || NAME="$(hostname)"
fi
if [[ -z "$TOKEN" ]]; then
  prompt "-s" "Device token: " TOKEN
fi
if [[ -z "$NAME" ]]; then
  NAME="$(hostname)"
  echo "using device name: $NAME (override with --name)"
fi
if [[ -z "$API" ]]; then
  prompt "" "API base URL: " API
fi

# Reporting options — the two subsystems, each with its own clock. Same two rows
# the Windows installer shows.
#
# On an upgrade these are asked *after* the new binary is in place, defaulted to
# what the device is set to now and applied with `bh-agent config set`, so a
# hand-tuned config keeps everything else it holds. The token and API URL are
# still never asked for on an upgrade — those are the ones an operator cannot
# re-supply. See apply_reporting_options below.
if [[ "$UPGRADE_ONLY" == "1" ]]; then
  :
else
  if [[ -z "$INTERVAL" ]]; then
    prompt_default "Upload device information and metrics every N minutes" \
      INTERVAL "$DEFAULT_INTERVAL"
  fi
  if [[ -z "$SCREENSHOTS" ]]; then
    # Defaults to no on an empty answer, so hitting Enter through the installer
    # never switches screen capture on.
    SCREENSHOT_ANSWER=""
    prompt_default "Upload the screen periodically? (y/n)" SCREENSHOT_ANSWER "n"
    case "$SCREENSHOT_ANSWER" in
      [yY]|[yY][eE][sS]) SCREENSHOTS=1;;
      *) SCREENSHOTS=0;;
    esac
  fi
  if [[ -z "$SCREENSHOT_INTERVAL" ]]; then
    if [[ "$SCREENSHOTS" == "1" ]]; then
      prompt_default "Capture the screen every N minutes" \
        SCREENSHOT_INTERVAL "$DEFAULT_SCREENSHOT_INTERVAL"
    else
      # Not asked when capture is off — the Windows page greys the same field
      # out. The default is still written, so the value is right if capture is
      # switched on later.
      SCREENSHOT_INTERVAL="$DEFAULT_SCREENSHOT_INTERVAL"
    fi
  fi
fi
if [[ "$UPGRADE_ONLY" != "1" ]]; then
  validate_interval --interval "$INTERVAL"
  validate_interval --screenshot-interval "$SCREENSHOT_INTERVAL"
fi

# Change the reporting options on an upgrade, without touching anything else in
# config.yaml.
#
# Rewriting the file is not an option here: it holds the token, and by now it may
# also hold a tuned queue, a chosen capture format, or a log level nobody wants
# reset. So each setting is read back with `config get`, offered as the default,
# and written with `config set`, which edits that one line and leaves comments
# and every other key alone.
#
# Only settings that actually changed are written, so an upgrade where the
# operator presses Enter through every question — or one with no terminal at
# all — touches nothing.
apply_reporting_options() {
  local bin="$1" current answer target changed=0

  current="$("$bin" config get agent.interval_minutes 2>/dev/null || true)"
  if [[ -z "$current" ]]; then
    # `config get` failing means the config did not load. Say so rather than
    # offering defaults that would silently overwrite a working device.
    echo "could not read the current settings; leaving them unchanged" >&2
    return 0
  fi

  target="$INTERVAL"
  if [[ -z "$target" ]]; then
    prompt_default "Upload device information and metrics every N minutes" target "$current"
  fi
  validate_interval --interval "$target"
  if [[ "$target" != "$current" ]]; then
    "$bin" config set agent.interval_minutes "$target" >/dev/null && changed=1
    echo "metrics interval: $current -> $target minutes"
  fi

  current="$("$bin" config get screenshots.enabled 2>/dev/null || echo false)"
  if [[ -n "$SCREENSHOTS" ]]; then
    [[ "$SCREENSHOTS" == "1" ]] && answer=true || answer=false
  else
    local reply="" shown
    [[ "$current" == "true" ]] && shown=y || shown=n
    prompt_default "Upload the screen periodically? (y/n)" reply "$shown"
    case "$reply" in
      [yY]|[yY][eE][sS]) answer=true;;
      *) answer=false;;
    esac
  fi

  # `config set screenshots.enabled` is deliberately not used: that key has a
  # second copy which the per-user capture process reads, and only the
  # `screenshots` subcommand updates both. Setting it directly would record a
  # decision that never takes effect — for a subsystem that records screen
  # contents, silently is the wrong way to fail.
  if [[ "$answer" != "$current" ]]; then
    if [[ "$answer" == "true" ]]; then
      "$bin" screenshots enable --restart >/dev/null && changed=1
      echo "screen capture: disabled -> ENABLED"
    else
      "$bin" screenshots disable --restart >/dev/null && changed=1
      echo "screen capture: enabled -> disabled"
    fi
  fi

  # Asked whenever capture will be on afterwards, including when it was already
  # on and is staying on — the interval is the thing most likely to be tuned.
  if [[ "$answer" == "true" ]]; then
    current="$("$bin" config get screenshots.interval_minutes 2>/dev/null || echo "$DEFAULT_SCREENSHOT_INTERVAL")"
    target="$SCREENSHOT_INTERVAL"
    if [[ -z "$target" ]]; then
      prompt_default "Capture the screen every N minutes" target "$current"
    fi
    validate_interval --screenshot-interval "$target"
    if [[ "$target" != "$current" ]]; then
      "$bin" config set screenshots.interval_minutes "$target" >/dev/null && changed=1
      echo "capture interval: $current -> $target minutes"
    fi
  fi

  SCREENSHOTS_EFFECTIVE="$answer"
  [[ "$changed" == "1" ]] || echo "settings unchanged"
}

# Reject values that could break out of the generated YAML, and validate the API
# URL here rather than letting the agent crash-loop after a cheerful "install
# complete". These mirror AgentConfig::validate in src/config/mod.rs.
for pair in "token:$TOKEN" "name:$NAME" "api:$API"; do
  field="${pair%%:*}"; value="${pair#*:}"
  case "$value" in
    *$'\n'*|*$'\r'*)
      echo "--$field must not contain newlines" >&2; exit 1;;
  esac
done
case "$TOKEN" in
  *[!\ -~]*|*\ *) echo "--token must be printable ASCII with no spaces" >&2; exit 1;;
esac
case "$API" in
  https://*) ;;
  http://localhost|http://localhost/*|http://localhost:*) ;;
  http://127.0.0.1|http://127.0.0.1/*|http://127.0.0.1:*) ;;
  *)
    echo "--api must be an https:// URL (http:// is allowed only for localhost)." >&2
    echo "got: $API" >&2
    exit 1;;
esac

OS="$(uname -s)"
BIN_SRC="$(dirname "$0")/bh-agent"
BIN_DIR="/usr/local/bin"
BIN_DST="$BIN_DIR/bh-agent"

# The binary ships in the release tarball next to this script; it is never
# committed to the repo, so a checkout has nothing to install.
if [[ ! -f "$BIN_SRC" ]]; then
  echo "bh-agent binary not found next to this script: $BIN_SRC" >&2
  echo "run this installer from an extracted release tarball, or build first:" >&2
  echo "  cargo build --release && cp target/release/bh-agent installer/" >&2
  exit 1
fi

# launchd and systemd execute $BIN_DST as root and neither checks who owns it.
# Write permission on the *directory* is enough to replace the file, so a
# non-root-owned or group/world-writable $BIN_DIR is a direct path to root. This
# is not hypothetical: on Intel Macs Homebrew's prefix IS /usr/local and its
# installer chowns /usr/local/bin to the installing user.
# GNU and BSD `stat` disagree about `-f`: BSD reads it as the format string,
# GNU as --file-system. Trying BSD first and falling back on failure does not
# work, because GNU still writes a filesystem dump to stdout before it fails and
# command substitution captures that alongside the fallback's output — yielding
# a blob rather than a uid, so every Linux install was refused. Pick the
# implementation once, up front, instead.
if stat -c '%u' / >/dev/null 2>&1; then
  stat_owner() { stat -c '%u' "$1"; }
  stat_mode() { stat -c '%a' "$1"; }
else
  stat_owner() { stat -f '%u' "$1"; }
  stat_mode() { stat -f '%OLp' "$1"; }
fi

assert_root_owned_dir() {
  local dir="$1"
  [[ -d "$dir" ]] || { echo "missing directory: $dir" >&2; exit 1; }
  local owner mode
  owner="$(stat_owner "$dir")"
  mode="$(stat_mode "$dir")"
  if [[ "$owner" != "0" ]]; then
    echo "refusing to install: $dir is owned by uid $owner, not root." >&2
    echo "A daemon binary there could be replaced without root, giving root on reboot." >&2
    echo "Fix with: sudo chown root '$dir'   (on Intel Macs this is usually Homebrew)" >&2
    exit 1
  fi
  # Strip the owner digit; anything group- or other-writable is disqualifying.
  if [[ "${mode: -2}" =~ [2367] ]]; then
    echo "refusing to install: $dir is group/world-writable (mode $mode)." >&2
    echo "Fix with: sudo chmod go-w '$dir'" >&2
    exit 1
  fi
}
assert_root_owned_dir "$BIN_DIR"

install -m 0755 -o root "$BIN_SRC" "$BIN_DST"

# macOS stamps com.apple.quarantine on anything obtained through a browser, and
# the agent is not notarized by Apple — so Gatekeeper SIGKILLs it on launch with
# no output at all, which looks like a broken binary rather than a policy block.
# `get-agent.sh` uses curl and is unaffected, but a manual install from a
# downloaded archive is a real path. Strip it from the copy we just installed.
if [[ "$OS" == "Darwin" ]] && command -v xattr >/dev/null 2>&1; then
  xattr -d com.apple.quarantine "$BIN_DST" 2>/dev/null || true
fi

write_config() {
  local dir="$1"
  # An upgrade must not discard local settings. config.yaml can now carry a
  # `screenshots:` block and a tuned interval, and blindly rewriting it would
  # silently disable screen capture and reset those on every reinstall. Pass
  # --force-config to overwrite deliberately (e.g. to rotate the token).
  if [[ -f "$dir/config.yaml" && "$FORCE_CONFIG" != "1" ]]; then
    echo "preserved existing $dir/config.yaml (use --force-config to rewrite)"
    return 0
  fi
  # 0700: the queue database beside this file holds a rolling multi-day record
  # of every process on the host, including other users' names and binary paths.
  install -d -m 0700 -o root "$dir"
  local cfg="$dir/config.yaml"
  umask 077
  # Quoted delimiter plus single-quoted, escaped values: without this a newline
  # in any value injects arbitrary YAML into the generated config.
  # YAML escapes a single quote inside a single-quoted scalar by doubling it.
  # Bash's ${var//\'/\'\'} emits literal backslashes here, which YAML would not
  # strip, so use sed.
  yaml_quote() { printf "'%s'" "$(printf '%s' "$1" | sed "s/'/''/g")"; }
  local screenshots_enabled=false
  [[ "$SCREENSHOTS" == "1" ]] && screenshots_enabled=true
  # Both subsystem blocks are written out even where the value matches the
  # agent's own default. This file is what an operator reads when asking "is
  # this machine capturing my screen?", and an absent `screenshots:` block only
  # answers that if you already know the default. Booleans are unquoted: the
  # agent's parser is strict, and 'true' in quotes is the string "true".
  {
    echo "api:"
    echo "  base_url: $(yaml_quote "$API")"
    echo "  timeout_seconds: 30"
    echo "  token: $(yaml_quote "$TOKEN")"
    echo "agent:"
    echo "  name: $(yaml_quote "$NAME")"
    echo "  interval_minutes: $INTERVAL"
    echo "metrics:"
    echo "  enabled: true"
    echo "screenshots:"
    echo "  enabled: $screenshots_enabled"
    echo "  interval_minutes: $SCREENSHOT_INTERVAL"
    echo "logging:"
    echo "  level: info"
  } > "$cfg"
  chmod 0600 "$cfg"
  echo "wrote $cfg (0600)"
}

if [[ "$OS" == "Linux" ]]; then
  write_config /etc/bh-agent
  install -d -m 0700 -o root /var/lib/bh-agent
  install -d -m 0750 -o root /var/log/bh-agent
  install -m 0644 "$(dirname "$0")/bh-agent.service" /etc/systemd/system/bh-agent.service
  systemctl daemon-reload
  systemctl enable --now bh-agent
  echo "systemd service enabled"
  # Upgrades replace the binary without re-running capture provisioning, so a
  # device that already opted into capture would otherwise never get the Wayland
  # runtime packages. The binary decides whether anything is needed: it is a
  # no-op while capture is disabled, which is the default and the fresh-install
  # case. Never fatal — the agent's own monitoring must come up regardless.
  "$BIN_DST" screenshots deps || true
elif [[ "$OS" == "Darwin" ]]; then
  write_config "/Library/Application Support/bh-agent"
  install -d -m 0750 -o root "/Library/Logs/bh-agent"
  install -m 0644 "$(dirname "$0")/com.beehive.bh-agent.plist" /Library/LaunchDaemons/com.beehive.bh-agent.plist
  launchctl load -w /Library/LaunchDaemons/com.beehive.bh-agent.plist
  echo "launchd daemon loaded"
else
  echo "unsupported OS: $OS" >&2; exit 1
fi

if [[ "$UPGRADE_ONLY" == "1" ]]; then
  # After the new binary is in place, so `config get`/`config set` are the
  # new version's — the settings offered are the ones this build understands.
  echo
  echo "Reporting settings (press Enter to keep the current value):"
  apply_reporting_options "$BIN_DST"
else
  echo "verifying connectivity: GET $API/health"
  if command -v curl >/dev/null; then
    curl -fsS "$API/health" >/dev/null && echo "health OK" || echo "health check failed (agent will retry)"
  fi
fi
echo "install complete"

# Screen capture (ADR-008) is opt-in and is NOT provisioned here: it runs as a
# per-user service, which must be installed by the user who will be captured, from
# inside their own GUI session. See README "Turning it on".
#
# Which is exactly why the enabled case still has a step left. Answering yes
# records the decision in config.yaml and nothing more; an operator not told
# that walks away believing capture is running.
echo
if [[ "$UPGRADE_ONLY" == "1" && "${SCREENSHOTS_EFFECTIVE:-false}" == "true" ]]; then
  echo "Screen capture is ENABLED for this device."
  echo "If a user's screen is not being captured yet, that user must run:"
  echo "  sudo bh-agent screenshots install    # run via sudo from the user's account"
  echo "To turn it off:"
  echo "  sudo bh-agent screenshots disable --restart"
elif [[ "$UPGRADE_ONLY" == "1" ]]; then
  echo "Screen capture is disabled. Current per-user state:"
  "$BIN_DST" screenshots status 2>/dev/null || true
elif [[ "$SCREENSHOTS" == "1" ]]; then
  echo "Screen capture is ENABLED for this device, every $SCREENSHOT_INTERVAL minutes."
  echo "No screen is captured yet. Each user to be captured must run, in their own session:"
  echo "  sudo bh-agent screenshots install    # run via sudo from the user's account"
  echo "To turn it off again:"
  echo "  sudo bh-agent screenshots disable --restart"
else
  echo "Screen capture is disabled. To enable it on this device:"
  echo "  sudo bh-agent screenshots enable --restart"
  echo "  sudo bh-agent screenshots install    # run via sudo from the user's account"
fi
