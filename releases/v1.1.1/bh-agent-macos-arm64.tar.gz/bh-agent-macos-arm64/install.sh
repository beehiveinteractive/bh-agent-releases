#!/usr/bin/env bash
set -euo pipefail

# macOS's stock sudoers does not set `secure_path`, so `env_reset` preserves the
# caller's PATH and root would resolve bare command names (curl, install,
# hostname) through directories the invoking user can write — Homebrew's
# /usr/local/bin on Intel Macs, or anything earlier on their PATH. Pin it.
PATH=/usr/bin:/bin:/usr/sbin:/sbin
export PATH

# Bracket ranges like [ -~] are matched in *collation* order, not ASCII order,
# and in a UTF-8 locale that order excludes ordinary alphanumerics — so the
# token validation below rejects every valid token unless the locale is pinned.
# `sudo` on macOS forwards the caller's LANG, so this cannot be left to chance.
LC_ALL=C
export LC_ALL

TOKEN=""
TOKEN_FILE=""
NAME=""
API=""

usage() {
  cat >&2 <<'USAGE'
usage: install.sh [--token-file PATH | --token VALUE] [--name NAME] [--api URL]

  --token-file  Read the device token from PATH (preferred: keeps the secret
                out of the process argument list, which is world-readable via
                /proc on Linux).
  --token       Device token as a literal argument. Discouraged; also readable
                from the environment variable BH_AGENT_SETUP_TOKEN instead.
  --name        Device name. Defaults to the hostname.
  --api         API base URL. Must be https:// (or http://localhost for dev).
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --token)      TOKEN="$2";      shift 2;;
    --token-file) TOKEN_FILE="$2"; shift 2;;
    --name)       NAME="$2";       shift 2;;
    --api)        API="$2";        shift 2;;
    -h|--help)    usage; exit 0;;
    *) echo "unknown arg: $1" >&2; usage; exit 1;;
  esac
done

# Interactive prompts must read from the terminal, not stdin: when this script
# runs via `curl | bash`, stdin is the exhausted script pipe and a plain `read`
# dies silently on EOF under `set -e`.
prompt() {
  local flags="$1" text="$2" __var="$3"
  if ! { : < /dev/tty; } 2>/dev/null; then
    echo "missing required argument (no terminal to prompt): $text" >&2
    echo "pass --token-file/--name/--api explicitly when running non-interactively" >&2
    exit 1
  fi
  local value
  read -r $flags -p "$text" value < /dev/tty
  [[ "$flags" == *s* ]] && echo
  printf -v "$__var" '%s' "$value"
}

# Token precedence: --token-file, then the environment, then --token, then a
# prompt. The first two keep the secret out of argv.
if [[ -n "$TOKEN_FILE" ]]; then
  [[ -r "$TOKEN_FILE" ]] || { echo "cannot read token file: $TOKEN_FILE" >&2; exit 1; }
  TOKEN="$(< "$TOKEN_FILE")"
  TOKEN="${TOKEN%%[$'\n\r']*}"
elif [[ -z "$TOKEN" && -n "${BH_AGENT_SETUP_TOKEN:-}" ]]; then
  TOKEN="$BH_AGENT_SETUP_TOKEN"
fi
if [[ -z "$TOKEN" ]]; then
  prompt "-s" "Device token: " TOKEN
fi
if [[ -z "$NAME" ]]; then
  NAME="$(hostname)"
  echo "using device name: $NAME (override with --name)"
fi
if [[ -z "$API" ]]; then
  prompt "" "API base URL: " API
fi

# Reject values that could break out of the generated YAML, and validate the API
# URL here rather than letting the agent crash-loop after a cheerful "install
# complete". These mirror AgentConfig::validate in src/config/mod.rs.
for pair in "token:$TOKEN" "name:$NAME" "api:$API"; do
  field="${pair%%:*}"; value="${pair#*:}"
  case "$value" in
    *$'\n'*|*$'\r'*)
      echo "--$field must not contain newlines" >&2; exit 1;;
  esac
done
case "$TOKEN" in
  *[!\ -~]*|*\ *) echo "--token must be printable ASCII with no spaces" >&2; exit 1;;
esac
case "$API" in
  https://*) ;;
  http://localhost|http://localhost/*|http://localhost:*) ;;
  http://127.0.0.1|http://127.0.0.1/*|http://127.0.0.1:*) ;;
  *)
    echo "--api must be an https:// URL (http:// is allowed only for localhost)." >&2
    echo "got: $API" >&2
    exit 1;;
esac

OS="$(uname -s)"
BIN_SRC="$(dirname "$0")/bh-agent"
BIN_DIR="/usr/local/bin"
BIN_DST="$BIN_DIR/bh-agent"

# The binary ships in the release tarball next to this script; it is never
# committed to the repo, so a checkout has nothing to install.
if [[ ! -f "$BIN_SRC" ]]; then
  echo "bh-agent binary not found next to this script: $BIN_SRC" >&2
  echo "run this installer from an extracted release tarball, or build first:" >&2
  echo "  cargo build --release && cp target/release/bh-agent installer/" >&2
  exit 1
fi

# launchd and systemd execute $BIN_DST as root and neither checks who owns it.
# Write permission on the *directory* is enough to replace the file, so a
# non-root-owned or group/world-writable $BIN_DIR is a direct path to root. This
# is not hypothetical: on Intel Macs Homebrew's prefix IS /usr/local and its
# installer chowns /usr/local/bin to the installing user.
assert_root_owned_dir() {
  local dir="$1"
  [[ -d "$dir" ]] || { echo "missing directory: $dir" >&2; exit 1; }
  local owner mode
  owner="$(stat -f '%u' "$dir" 2>/dev/null || stat -c '%u' "$dir")"
  mode="$(stat -f '%OLp' "$dir" 2>/dev/null || stat -c '%a' "$dir")"
  if [[ "$owner" != "0" ]]; then
    echo "refusing to install: $dir is owned by uid $owner, not root." >&2
    echo "A daemon binary there could be replaced without root, giving root on reboot." >&2
    echo "Fix with: sudo chown root '$dir'   (on Intel Macs this is usually Homebrew)" >&2
    exit 1
  fi
  # Strip the owner digit; anything group- or other-writable is disqualifying.
  if [[ "${mode: -2}" =~ [2367] ]]; then
    echo "refusing to install: $dir is group/world-writable (mode $mode)." >&2
    echo "Fix with: sudo chmod go-w '$dir'" >&2
    exit 1
  fi
}
assert_root_owned_dir "$BIN_DIR"

install -m 0755 -o root "$BIN_SRC" "$BIN_DST"

write_config() {
  local dir="$1"
  # 0700: the queue database beside this file holds a rolling multi-day record
  # of every process on the host, including other users' names and binary paths.
  install -d -m 0700 -o root "$dir"
  local cfg="$dir/config.yaml"
  umask 077
  # Quoted delimiter plus single-quoted, escaped values: without this a newline
  # in any value injects arbitrary YAML into the generated config.
  # YAML escapes a single quote inside a single-quoted scalar by doubling it.
  # Bash's ${var//\'/\'\'} emits literal backslashes here, which YAML would not
  # strip, so use sed.
  yaml_quote() { printf "'%s'" "$(printf '%s' "$1" | sed "s/'/''/g")"; }
  {
    echo "api:"
    echo "  base_url: $(yaml_quote "$API")"
    echo "  timeout_seconds: 30"
    echo "  token: $(yaml_quote "$TOKEN")"
    echo "agent:"
    echo "  name: $(yaml_quote "$NAME")"
    echo "  interval_minutes: 5"
    echo "logging:"
    echo "  level: info"
  } > "$cfg"
  chmod 0600 "$cfg"
  echo "wrote $cfg (0600)"
}

if [[ "$OS" == "Linux" ]]; then
  write_config /etc/bh-agent
  install -d -m 0700 -o root /var/lib/bh-agent
  install -d -m 0750 -o root /var/log/bh-agent
  install -m 0644 "$(dirname "$0")/bh-agent.service" /etc/systemd/system/bh-agent.service
  systemctl daemon-reload
  systemctl enable --now bh-agent
  echo "systemd service enabled"
elif [[ "$OS" == "Darwin" ]]; then
  write_config "/Library/Application Support/bh-agent"
  install -d -m 0750 -o root "/Library/Logs/bh-agent"
  install -m 0644 "$(dirname "$0")/com.beehive.bh-agent.plist" /Library/LaunchDaemons/com.beehive.bh-agent.plist
  launchctl load -w /Library/LaunchDaemons/com.beehive.bh-agent.plist
  echo "launchd daemon loaded"
else
  echo "unsupported OS: $OS" >&2; exit 1
fi

echo "verifying connectivity: GET $API/health"
if command -v curl >/dev/null; then
  curl -fsS "$API/health" >/dev/null && echo "health OK" || echo "health check failed (agent will retry)"
fi
echo "install complete"
