#!/usr/bin/env bash
set -euo pipefail
OS="$(uname -s)"
if [[ "$OS" == "Linux" ]]; then
  systemctl disable --now bh-agent || true
  rm -f /etc/systemd/system/bh-agent.service
  systemctl daemon-reload
  rm -rf /etc/bh-agent /var/lib/bh-agent /var/log/bh-agent
elif [[ "$OS" == "Darwin" ]]; then
  launchctl unload -w /Library/LaunchDaemons/com.beehive.bh-agent.plist || true
  rm -f /Library/LaunchDaemons/com.beehive.bh-agent.plist
  rm -rf "/Library/Application Support/bh-agent" "/Library/Logs/bh-agent"
fi
rm -f /usr/local/bin/bh-agent
echo "uninstalled"
