#!/usr/bin/env bash
set -euo pipefail

TOKEN=""
NAME=""
API=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --token) TOKEN="$2"; shift 2;;
    --name)  NAME="$2";  shift 2;;
    --api)   API="$2";   shift 2;;
    *) echo "unknown arg: $1" >&2; exit 1;;
  esac
done

# Interactive prompts must read from the terminal, not stdin: when this script
# runs via `curl | bash`, stdin is the exhausted script pipe and a plain `read`
# dies silently on EOF under `set -e`.
prompt() {
  local flags="$1" text="$2" __var="$3"
  if ! { : < /dev/tty; } 2>/dev/null; then
    echo "missing required argument (no terminal to prompt): $text" >&2
    echo "pass --token/--name/--api explicitly when running non-interactively" >&2
    exit 1
  fi
  local value
  read -r $flags -p "$text" value < /dev/tty
  [[ "$flags" == *s* ]] && echo
  printf -v "$__var" '%s' "$value"
}

if [[ -z "$TOKEN" ]]; then
  prompt "-s" "Device token: " TOKEN
fi
if [[ -z "$NAME" ]]; then
  NAME="$(hostname)"
  echo "using device name: $NAME (override with --name)"
fi
if [[ -z "$API" ]]; then
  prompt "" "API base URL: " API
fi

OS="$(uname -s)"
BIN_SRC="$(dirname "$0")/bh-agent"
BIN_DST="/usr/local/bin/bh-agent"

install -m 0755 "$BIN_SRC" "$BIN_DST"

write_config() {
  local dir="$1"
  install -d -m 0755 "$dir"
  local cfg="$dir/config.yaml"
  umask 077
  cat > "$cfg" <<EOF
api:
  base_url: $API
  timeout_seconds: 30
  token: $TOKEN
agent:
  name: $NAME
  interval_minutes: 5
logging:
  level: info
EOF
  chmod 0600 "$cfg"
  echo "wrote $cfg (0600)"
}

if [[ "$OS" == "Linux" ]]; then
  write_config /etc/bh-agent
  install -d -m 0755 /var/lib/bh-agent /var/log/bh-agent
  install -m 0644 "$(dirname "$0")/bh-agent.service" /etc/systemd/system/bh-agent.service
  systemctl daemon-reload
  systemctl enable --now bh-agent
  echo "systemd service enabled"
elif [[ "$OS" == "Darwin" ]]; then
  write_config "/Library/Application Support/bh-agent"
  install -d -m 0755 "/Library/Logs/bh-agent"
  install -m 0644 "$(dirname "$0")/com.beehive.bh-agent.plist" /Library/LaunchDaemons/com.beehive.bh-agent.plist
  launchctl load -w /Library/LaunchDaemons/com.beehive.bh-agent.plist
  echo "launchd daemon loaded"
else
  echo "unsupported OS: $OS" >&2; exit 1
fi

echo "verifying connectivity: GET $API/health"
if command -v curl >/dev/null; then
  curl -fsS "$API/health" >/dev/null && echo "health OK" || echo "health check failed (agent will retry)"
fi
echo "install complete"
