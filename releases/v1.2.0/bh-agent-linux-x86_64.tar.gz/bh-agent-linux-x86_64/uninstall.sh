#!/usr/bin/env bash
set -euo pipefail
OS="$(uname -s)"

# Screen capture (ADR-008) runs as a *per-user* agent, not as the root daemon,
# because a daemon has no display access. Its unit, credential file and spooled
# captures therefore live in each user's home and are invisible to the root
# uninstall below. Left behind, the spool would keep screen contents on disk after
# the agent was supposedly removed — so every user's copy is cleaned up here.
remove_capture_agents() {
  local label="com.beehive.bh-agent-screenshots"
  local unit="bh-agent-screenshots.service"

  # Every real home directory, whichever platform's layout this is.
  local homes=()
  if [[ -d /Users ]]; then homes+=(/Users/*); fi
  if [[ -d /home ]]; then homes+=(/home/*); fi
  homes+=("$HOME")

  for home in "${homes[@]}"; do
    [[ -d "$home" ]] || continue
    local user
    user="$(basename "$home")"
    local uid
    uid="$(id -u "$user" 2>/dev/null || true)"

    if [[ "$OS" == "Darwin" ]]; then
      if [[ -n "$uid" ]]; then
        launchctl bootout "gui/$uid" "$home/Library/LaunchAgents/$label.plist" 2>/dev/null || true
      fi
      rm -f "$home/Library/LaunchAgents/$label.plist"
      rm -rf "$home/Library/Application Support/bh-agent"
    else
      if [[ -n "$uid" ]]; then
        sudo -u "$user" env "XDG_RUNTIME_DIR=/run/user/$uid" \
          systemctl --user disable --now "$unit" 2>/dev/null || true
      fi
      rm -f "$home/.config/systemd/user/$unit"
      # Both the XDG default and an XDG_STATE_HOME that pointed elsewhere are
      # unknowable from here, so the documented default is what gets removed.
      rm -rf "$home/.local/state/bh-agent"
    fi
  done
}

remove_capture_agents
if [[ "$OS" == "Linux" ]]; then
  systemctl disable --now bh-agent || true
  rm -f /etc/systemd/system/bh-agent.service
  systemctl daemon-reload
  rm -rf /etc/bh-agent /var/lib/bh-agent /var/log/bh-agent
elif [[ "$OS" == "Darwin" ]]; then
  launchctl unload -w /Library/LaunchDaemons/com.beehive.bh-agent.plist || true
  rm -f /Library/LaunchDaemons/com.beehive.bh-agent.plist
  rm -rf "/Library/Application Support/bh-agent" "/Library/Logs/bh-agent"
fi
rm -f /usr/local/bin/bh-agent
echo "uninstalled"
